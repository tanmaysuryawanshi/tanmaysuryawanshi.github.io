(function () {
  function addCustomTimeFilter() {
    let filterList = document.querySelector(".dept-time.at-time-filter");
    if (!filterList) return;

    // Avoid adding the filter multiple times
    if (document.getElementById("customTimeFilter")) return;

    // Create new custom filter UI
    let customFilterHTML = `
            <li class="checkbox" id="customTimeFilter">
                <label>Custom Time Range:</label><br>
                <input type="time" id="customStartTime"> to 
                <input type="time" id="customEndTime">
                <button id="applyCustomFilter" class="g-button">Apply</button>
                <button id="resetCustomFilter" class="g-button reset">Reset</button>
            </li>
        `;

    filterList.insertAdjacentHTML("beforeend", customFilterHTML);

    // Event listener for apply button
    document
      .getElementById("applyCustomFilter")
      .addEventListener("click", () => {
        let startTime = document.getElementById("customStartTime").value;
        let endTime = document.getElementById("customEndTime").value;
        if (startTime && endTime) {
          filterBusesByTime(startTime, endTime);
        } else {
          alert("Please select a valid time range.");
        }
      });

    // Event listener for reset button
    document
      .getElementById("resetCustomFilter")
      .addEventListener("click", resetFilters);
  }

  function filterBusesByTime(startTime, endTime) {
    let startHour = parseInt(startTime.split(":")[0]);
    let startMinute = parseInt(startTime.split(":")[1]);

    let endHour = parseInt(endTime.split(":")[0]);
    let endMinute = parseInt(endTime.split(":")[1]);

    let busContainers = document.querySelectorAll(".row-sec.clearfix");

    busContainers.forEach((container) => {
      let busCard = container.querySelector(".clearfix.bus-item");
      if (!busCard) return;

      let timeElement = busCard.querySelector(".dp-time.f-19.d-color.f-bold");
      if (!timeElement) return;

      let [hour, minute] = timeElement.textContent
        .trim()
        .split(":")
        .map(Number);

      // Hide buses outside the selected range
      if (
        hour < startHour ||
        (hour === startHour && minute < startMinute) ||
        hour > endHour ||
        (hour === endHour && minute > endMinute)
      ) {
        container.style.display = "none";
      } else {
        container.style.display = "block";
      }
    });
  }

  function resetFilters() {
    let busContainers = document.querySelectorAll(".row-sec.clearfix");
    busContainers.forEach((container) => {
      container.style.display = "block"; // Show all buses
    });

    document.getElementById("customStartTime").value = "";
    document.getElementById("customEndTime").value = "";
  }

  function waitForElement(selector, callback) {
    let observer = new MutationObserver((mutations, obs) => {
      if (document.querySelector(selector)) {
        callback();
        obs.disconnect();
      }
    });

    observer.observe(document, { childList: true, subtree: true });
  }

  waitForElement(".dept-time.at-time-filter", addCustomTimeFilter);
})();
